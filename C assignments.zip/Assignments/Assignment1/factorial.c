#include<stdio.h>

int factorial(int);

int main()
{
	int num=0,fact;
	printf("Please enter the number to find the factorial\n\n Number: ");
	scanf("%d",&num);
 
       fact=factorial(num);
       printf("\n\nThe factorial is %d",fact);
}

int factorial(int fact)
{
	if(fact==0 || fact==1)
	{
         return 1;
	}
	else
	return (fact*factorial(fact-1));
}

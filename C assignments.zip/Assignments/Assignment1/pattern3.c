//this code will print the given pattern
//        1
//       222
//      33333
//     4444444
//    555555555
//
#include<stdio.h>

int main()
{
	int i,j,k,space=5;

	for(i=1; i<6; i++)
	{
	 for(k=0; k<space-i; k++)
	 {
	  printf(" ");
	 }

	 for(j=1;j<=i+i-1;j++)
	 {
	 printf("%d",i);
	 }
	 printf("\n");
	}
}

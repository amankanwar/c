#include<stdio.h>

int main()
{
	int input,fact=1;

	printf("Please enter the number to find the factorial\n\n Number: ");
	scanf("%d",&input);

        for(input; input>0; input--)
	{
	fact=fact*input;
	}

	printf("\n\nFactorial is %d",fact);

        return 0;
}


// this program checks whether the given input character is a vowel or not
#include<stdio.h>

int main()
{

  char ch;
  int i=0;
  
  printf("\nEnter the Character: ");
  scanf("%c",&ch);  

  char vowel[]= "aeiouAEIOU";

  while(vowel[i]!='\0')
  {
   if(vowel[i] == ch)
	{ 
	printf("It is a vowel\n");
        return 0;	
        }
   else
   ++i;
  }
  printf("It is a consonent\n");
  return 0;
}

#include<stdio.h>

int main()
{
 int i=0,j,input;
 float sum=0;
 printf("\nPlease enter the number you wish to enter and add\n\nNumber: ");
 scanf("%d",&j);

 for(i=1; i<=j; i++)
 {
	 printf("Value: ");
	 scanf("%d",&input);
	 sum=sum+input;
 }
 
 printf("Total Sum: %f and average is %f",sum,sum/j); 
 return 0;
}

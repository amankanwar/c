// This program swaps two number without using the third variable

#include<stdio.h>
int main()
{
	int a,b;
	printf("Please Enter Numbers\n Number1: ");
        scanf("%d",&a);
        printf("NUmber 2: ");
	scanf("%d",&b);
/////////////////////////////////
	a=a+b;
	b=a-b;
	a=a-b;
/////////////////////////////////
	printf("Value of a= %d value of the number b= %d\n",a,b);
       return 0;	
}

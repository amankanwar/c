//This program reverses a given 3 digit number
#include<stdio.h>
int main()
{
	int n,rev;
	printf("Enter any  digit number: ");
	scanf("%d",&n);
	rev = 0;
	while(n!=0)
	{
		rev = rev*10 +n%10;
		n=n/10;
	}
	printf("Reversed no. : %d\n",rev);
  return 0;
}

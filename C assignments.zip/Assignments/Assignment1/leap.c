// this given program find out that whether the entered year is a leap year or not

#include<stdio.h>

int main()
{
int year; 
printf("Please enter the Year: ”);
scanf(“%d”,&year);

if(year%100 == 0 || year%4==0)
{
 printf("The given Year %d is a leap year\n",year);
 return 0;
}
else
printf("Year %d is not a leap year",year);
return 0;
}

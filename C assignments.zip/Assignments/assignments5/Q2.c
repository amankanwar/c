/*Q2. WAP to Addition of two arrays
 *
 * Auther: Aman Kanwar
 *
 * I will implement this code by calculating the length of the both the input string and then using the malloc to allocate
 * new memory equal to the size of the combined string + 1 null character
 *
 * All this implemented by creating a new function which takes parameters provided by main and then calling the function 
 * within the main function and then providing values to the new string.
 *
 * V1.0
 */

#include<stdio.h>
#include<stdlib.h>

//--------Declarations----------------------
char *addition(char *, char *,unsigned int);
//------------------------------------------

int main(void)
{

//-------Vriables--------------------------
 unsigned int length_of_string=0;
 int i=0,j=0;

 char input[30];
 char input2[30];

 char *new_string;
//-----------------------------------------

//======== String Input from User ========
 printf("\n\n\t\tString1: ");
 scanf("%[^\n]s",input);     // accepting the all the inputs except \n space as well
 
 while((getchar())!='\n');   // this will clear the input buffer

 printf("\n\t\tString2: ");
 scanf("%[^\n]s",input2);    // accepting all the iputs except \n
//======================================= 

 
 while(input[i++] != '\0');   // Incrementing the value of i from 0 to the value till the string1 doesn't reaches its null character
 while(input2[j++] != '\0');  // Incrementing the value of j similar to i but with in reference to the index of the string2


length_of_string= i+j;        // Total Length of the string will be the sum of the individual length of the previous strings


//XXXXXXXXXXX For Testing XXXXXXXXXXXXXXXXXXXXX
//printf("\n\nLength is string is %d",length_of_string);
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

// Please note that the length of input will be = string1 + null_character_string1 + string2 + null character_string2

new_string = addition(input,input2,length_of_string);  //--Here we are calling the function and assiging the pointer with the returned address

printf("\n\nNew String:  %s \n\n",new_string);  //--Printing the Output of the pointer new_string

free(new_string);                                      //--Deallocating the memory provided to the new_string pointer

return 0;
}

//------------------------------------------------------------------------------------

char *addition(char *string1, char *string2,unsigned int len)
{
 int index=0;  

 char *new_string;

//IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
 // now we need to allocate memory to the new_string variable
 // note that the 'len' variable is having the actual length + 2 (null characters count)
 // hence allocating the memory keeping the same in mind
//IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII 

 new_string = (char *)malloc(sizeof(char)*len);  // Allocating memeory to the new_string based on the size of input strings
 
 while(string1[index]!='\0')
 {		 
  new_string[index] = string1[index];
  index++;
 }

//XXXXXXX Testing XXXXXXXXXXXXXXXXXXXXXXXXXXXX
  //printf("\n\nValue of Index is %d\n\n",index);
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
 int index2=0;
 
  new_string[index++]=' ';  //Adding a space after the input of string1, further incrementing the index value

 while(string2[index2]!='\0')
 {
  new_string[index] = string2[index2];
  
//XXXXXXX Testing XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
  //printf("\nnew_string = %c",new_string[index]);
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
  
  index++;                  // here we are incrementing the value of index to locate to the next memory location of pointer new_string
  index2++;                 // here index2 is incremented to increase the index value of the porinter string2
 }
 
 new_string[index++]=' ';   // at this point we are adding a '\0' or space to the ending of the string

return new_string;
}
//----------------------------------------------------------------------------------------------------------------

//Q1. WAP to Reverse an array in memory
//
#include<stdio.h>
#include<string.h>
//
//------------------------------------------------------------------------------------------------------------------------------
void reverse(char *); // function prototype
//------------------------------------------------------------------------------------------------------------------------------
int main(void)
{	
 char input[30];
 unsigned int length;
 printf("Please enter the String to reverse\n\nInput: ");
 scanf("%[^\n]s",input);         // this scanf() has implemented the data set in order to include spaces" "
 reverse(input);                 // this function will reverse the string array
 printf("\n\nValue of the string is %s\n\n",input);  // printing the value of the string array
 return 0;
}
//-------------------------------------------------------------------------------------------------------------------------------

//--This is the function to reverse the input string-----------------------------------------------------------------------------

void reverse(char *input)
{	
  int len=0;
  while(input[len++]!='\0');  //this while loop is used to calculate the length of the string
                              // please note that the length of array is showing to be one 
  int i=0,j=len-2;            // there variables are used to swap the values of array

/* here we have subtracted 2 from j and assigned to to len because the 'len' parameter is shwowing the length=length+1 (of input)
   because of the \0 at the end
   example for input "aman" len=5 (as caculated by expression)
   Hence the index of the string will be s[0]=a; s[1]=m; s[2]=a; s4[3];
   Hence the loop should run from 0----3 ; total 4 times but length = 5, hence, we subtracted 2 from length
   so new length=3, ie 4 index (0,1,2,3)  
*/

  char temp;    
  while(i<=j)
  {
    temp=input[i];
    input[i]=input[j];
    input[j]=temp;
    i++;
    j--;
  }
}
//------------------------------------------------------------------------------------------------------------------

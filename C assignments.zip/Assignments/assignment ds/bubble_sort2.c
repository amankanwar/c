// bubble sort in this case is applied with better approach wherein the given algorithm is provided a feature to detect that the data is already sorted (in cases)
// Hence, the further loops can be avoided in order to be implemented on the given data array_

// hence, a better approach is applied in the next applied code

#include<stdio.h>
#include<stdbool.h>

void swap(int *n1, int *n2);

int main(void)
{
   int data[10]     =  {0};
   bool sorted_flag =  true;
   int i=0,j=0;
//--------------asking for the user input inputs--------------------

   printf("Please Enter the 10 Numbers: ");

   for(i = 0; i<10; i++)
   {
    printf("\n\nNumber %d: ",i+1);
    scanf("%d",&data[i]);
   }
   
   for(i=0; i<10; i++)
   {
       for(j=0; j<10 -(i+1); j++)
       {
        	if(data[j] > data[j+1])
	          {
	 	    swap(&data[j],&data[j+1]);
                    sorted_flag = false;
	          }	

       }
       
       if(sorted_flag == true)
       {
        break;          // this will break the loop in case the entered data is sorted   
                       	// Hence, the second loop will not run again as the data is already sorted
       }
   }

        printf("\n\nLoop run %d times\n",i+1);
   
	i=10;

     	j=0;
   while(j<i)
   {
   printf("Value is %d\n",data[j++]);
   }

}

void swap(int *n1, int*n2)
{
 int temp;
 temp =  *n1;
 *n1  =  *n2;
 *n2  = temp;
}

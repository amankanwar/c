// this approach uses normal bubble approach for sorting the data.
// however the given algorithm used is having the best case of OMEGA (N^2)
// hence, a better approach is applied in the next applied code

#include<stdio.h>

void swap(int *n1, int *n2);

int main(void)
{
   int data[10] =  {0};

   int i=0,j=0;
//--------------asking for the user input inputs--------------------

   printf("Please Enter the 10 Numbers: ");

   for(i = 0; i<10; i++)
   {
    printf("\n\nNumber %d: ",i+1);
    scanf("%d",&data[i]);
   }
   
   for(i=0; i<10; i++)
   {
      for(j=0; j<10 -(i+1); j++)
      {
	if(data[j] > data[j+1])
	   {
		   swap(&data[j],&data[j+1]); 
	   }	

      }
      
       printf("\n\nLoop run %d times\n",i+1);
   }

   i=10;
   j=0;
   while(j<i)
   {
   printf("Value is %d\n",data[j++]);
   }

}

void swap(int *n1, int*n2)
{
 int temp;
 temp =  *n1;
 *n1  =  *n2;
 *n2  = temp;
}

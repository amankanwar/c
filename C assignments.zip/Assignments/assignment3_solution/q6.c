/*Q6. Implement a C program using formatted I/O using printf (%5d, %05d,
%-5d,%8.2f, %.2f etc.)
*/

#include<stdio.h>
#include<stdlib.h>

int main(void)
{
        int val1,val2,val3,result=0;
	float float_val=0;

	printf("This program implements the format specifiers in the given inputs");
 
	printf("\n\nUpcoming Inputs store only 6 digit number, more than 6 number are truncated");

	printf("\n\nNumber1: ");
	scanf("%6d",&val1);
        while((getchar())!='\n');

	printf("\nNumber2: ");
	scanf("%6d",&val2);
        while((getchar())!='\n');

	printf("\nNumber3: ");
	scanf("%5d",&val3);
        while((getchar())!='\n');

       printf("\n\nNow we will print this result in using formatted output wherein 7 blocks are alloted for each variable");


	printf("\n\nInput 1: %7d",val1);

	printf("\nInput 2: %7d",val2);

	printf("\nInput 3: %7d\n",val3);

return 0; 
}

//Q9. Implement a C program for number conversions (decimal, binary,
//octal, hexadecimal).
//
#include<stdio.h>

int convert_to_hex(int,char *);
int main(void)
{
int input=0;
char choice;
unsigned int conversion_to_octal=0; /// still not used
char hex_value[15];
unsigned int length;

printf("Please enter a Decimal Number: ");

//---Decimal Number Input from the user----

scanf("%d",&input);
getchar();
//---Conversion Type Selection------------

printf("\nPlease Choose from the following\n\nBinary: B\t\tHexadecimal: H\t\tOctal: O \n\t\tChoice: ");
scanf("%c",&choice);

//------Function Call based on the choice of user-------------------
	switch(choice)
	{
          case 'B':
	  case 'b':
                {
			printf("\n\nYet not implemented\n\n");
			return 0;
		}
	  case 'H':
	  case 'h':
	       {
                  length=convert_to_hex(input,hex_value);
		  break;
	       }	

	  case 'O':
	  case 'o':
	     {	
     	               printf("\n\nYet not implemented\n\n");
	               return 0;
	     }
            default:
	     printf("\n\nWrong Selection\n");
	     return 0;
	}

//////////////////////Here we will display the converted Hexadecimal Elements//////////////////////////

int len=length-1;
	
	printf("\n\n\n\t\tDecimal Value: %d Hexadecimal Value: 0x",input);
	while(len>=0)
		{
		printf("%c",hex_value[len--]);	
		}
         printf("\n");
//-------------------------------------------------------------------------------------------------------
	return 0;
}


int convert_to_hex(int input,char *hex_value)
{
int n=0,rem=0;
int index=0;

char ref[]="0123456789ABCDEF";  // lookup table to implement the conversion equilant

n=input;

while(n!=0)
{
 rem=n%16;        
	 // this expression will match the decimal value to its corresponding Hex Value in the array reference
	                                 // example if remainder is 11 then 11-10=1 and reference[1] is 'B'
//printf("\n\n==========>We are here<================ %d",rem);	

// printf("\n\n\n\t\tDecimal Value: %d",input);
	 hex_value[index]=ref[rem];
//         printf("\n\nHexadecimal Value is %c\n\n",hex_value[index]);
 

           // increment the value of index, we will return this value to the main function to make track on the number of converted inputs;
 index++;  // Here an extra element is inserted at the end of the array
 n=n/16;
}
//-------Temp----------/*
/*        printf("Hexadecimal Value is: ");
        int len=index-1;
	while(len>=0)
		{
		printf("%c",hex_value[len--]);	
		}
        printf("\n");
*/
//---------------------

return index;

}

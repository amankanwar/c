/*Q5. Write a program to convert time between hh:mm:ss format and total
no.of seconds

(note:- you may take the input hh,mm,ss separately, need not be in
string form)
for eg:- 1:2:30 ==> 3750
8000 ==> 2:13:20 )
*/

#include<stdio.h>

void convert_to_time(long unsigned int,int *);
long unsigned convert_to_seconds(int *);


int main(void)
{
  int time[3]={0};   // this array will be treated to be consisting of the format HH: MM: SS at the location time[0]:timep[1]:time[2]
  
  long unsigned int seconds;

  char input;

  printf("####################Time Convertor#####################");


  printf("\n\n\t==>Please select the Type of Convestion<==\n\nSeconds to HH:MM:SS---Press A\n\nHH:MM:SS to Seconds---Press B\n\n\t\t\t\tInput: ");
  scanf("%c",&input);
  
  switch(input)
  {
    case 'A':
    case 'a':
         {
	  printf("\n\nPlease Enter Number of seconds: ");
	  scanf("%ld",&seconds);
	  convert_to_time(seconds,time);
	  break;
	 }
	    
    case 'B':
    case 'b':
	 {
	  printf("\n\nPlease Enter following details");

           printf("\n\n\n\t\t\tHour   : ");
           scanf("%d",time);
           printf("\n    \t\t\tMinutes: ");
           scanf("%d",1+time);
           printf("\n    \t\t\tSeconds: ");
           scanf("%d",2+time);
	   seconds=convert_to_seconds(time);
	   break;	 
	 }
     default:
	 return 0;
	 
  }

  if(input == 'A' || input =='a')       // if the conversion was requested from Seconds to HH:MM:SS
  {
  printf("\n\n\t\tConversion of %ld seconds in Format Hour:Minutes:Seconds is\n\n",seconds);
  
  printf("\n\n\n\t\t\tHour   : %d",*time);
  printf("\n    \t\t\tMinutes: %d",*(time+1));
  printf("\n    \t\t\tSeconds: %d\n\n",*(time+2));
  }

  else if(input == 'B' || input == 'b') // if the conversion was requested from HH:MM:SS the execute the enclosed statements
  {
  printf("Total Number of seconds in %d Hour %d Minutes %d Seconds is %ld\n\n",time[0],time[1],time[2],seconds);
  }

  return 0;

}


void convert_to_time(long unsigned int seconds,int *time)
{
 unsigned int hour=0,min=0,sec=0;

 if(seconds>=60)
 { 
 sec=seconds%60;  // seconds to minutes and storing the remainder (seconds) to sec
 min=seconds/60; // converting seconds to minutes
 }
 if(min>=60)  // perform a while loop till the time the seconds are higher than 60
 { 
  hour=min/60;
  min=min%60;
 }
 time[0]=hour;
 time[1]=min;
 time[2]=sec;
}

long unsigned convert_to_seconds(int *time)
{
return((time[0]*60*60)+(time[1]*60)+(time[2]));
}



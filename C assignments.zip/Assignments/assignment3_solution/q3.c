/*Q3. Implement a C program to Differentiate between post, pre decrement
operators, consider below mention scenario.
a) k=i++, k=++i
b) y=x++*10, y=++x*10
c) q=p--/3, q=--p/3
*/

#include<stdio.h>

void pre_operator();

void post_operator();

int main(void)
	{
        char choice;	
	printf("\n\n\t\tThis Program will show the basic difference between post and pre increment operators,\ntopics are discoussed below");
     
	printf("\n\nPre Pre-Operator: A\t\t\tPost-Oprestors: B\n\nSelection: ");
        scanf("%c",&choice);
        
	 switch(choice)
	  {
		case 'A':
                case 'a':
		{
		 pre_operator();	
	         break;
		}

		case 'B':
                case 'b':
		{
		 post_operator();	
	         break;
		}
	  }
	 return 0;
	}

 void pre_operator()
 {
    int res=0,num=0;
 
  printf("\n\nThis Section provides information about the pre-increment operator and the difference, \nPress ENTER");

  getchar();
  
  printf("A pre-increment operator is used to increment the value of a variable before using it in a expression. \nIn the Pre-Increment, value is first incremented and then used inside the expression,\n\n");

  getchar();

  printf("k=++i (here the value of 'i' is increment first then it is assigned to the variable k)\n\nExample: Press Enter");

  getchar();

  printf("\n\nWe will implement Result = ++Number\n\nEnter Number: ");
  scanf("%d",&num);
  
  res=++num;
   
  getchar();

  printf("Value of 'Resut' is %d  because an increment of 1 is applied to the orignal value of 'Number' and then assigned to 'Result'",res);

  getchar();

  printf("\n\nInternal Operation is provided below:\nResult = ++Number\n\nResult= (Number=Number+1)");

  getchar();

  printf("\n\nHere in pre-increment the value of operand is incemented first then assigned");

  getchar();

  printf("\n\nSimilarly if we have\n\nResult=++number*10\n\nThen expression is simplified as follows\n\nResult=(Number=Number+1)*10");

  printf("\n\nEnter Number: ");
  scanf("%d",&num);

  res=++num*3;

  getchar();

  printf("Result of expression\n\nResult = ++number*3 is \n\nResult=%d",res);
 }

 void post_operator()
 {
  
    int res=0,num=0;
 
  printf("\n\nThis Section provides information about the pre-increment operator and the difference");
  
  printf("A pre-increment operator is used to increment the value of a variable before using it in a expression. \nIn the Pre-Increment, value is first incremented and then used inside the expression\n\n");

  printf("k=++i (here the value of 'i' is increment first then it is assigned to the variable k)\n\nExample: ");

  printf("\n\nWe will implement Result = Number++\n\nEnter Number: ");
  scanf("%d",&num);
  
  res=num++;

  printf("Value of 'Result' is %d  because value of 'Number' is assigned to Result Vriable first and then number is incremented",res);

  printf("\n\nInternal Operation is provided below:\nResult = Number++\n\nResult= Number, then increment the number");

  printf("\n\nHere in pre-increment the value of operand is incemented first then assigned");

  printf("\n\nSimilarly if we have\n\nResult=number++*10\n\nThen expression is simplified as follows\n\nResult=(Number)*10 then increment Number by 1");

  printf("\n\nEnter Number: ");
  scanf("%d",&num);

  res=num++*3;

  printf("Result of expression\n\nResult = ++number*3 is \n\nResult=%d Number= %d",res,num);
 }

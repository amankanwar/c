//Q8. Implement a C program based on integer array. Implement method
//to find average, sum, min element, max element.
//
//
#include<stdio.h>

void find_avg_min_max(int *,float *,int);   // (array,length of array)

int main(void)
{
	int input[8],n=0;
	float result[3]; // here result[0]= minimum value; result[1]= average; result[2]=maximum value;

	printf("Please enter the requested inputs\n\n");

	while(n<8)
	{
	 printf("\n\nInput: ");
	 scanf("%d",input+n);
	 ++n;
	}

	find_avg_min_max(input,result,n-1);

	printf("\n\n\t\tMinimum Element:%5f\n\t\tAverage        :%5f\n\t\tMaximum Element:%5f\n",*result,*(result+1),*(result+2));
return 0;
}


void find_avg_min_max(int *input,float *result,int length)   // (array,length of array)
{
 int max=0,min=0,n=0;
 float avg=0;      // we are using this variable to calculate the average in float

 min=*(input);    // at this line i am assigning the first element of the array to the min variable
 max=*(input+length);  // here the last element of the array is considered to be as largest number

 while(n<=length)  // this will triverse the entire array
 {
  
  avg=avg + *(input+n);  // we are doing explicit type casting here and caluclating the total of the input number
 
  if(min>input[n])  //finding the smallest element in the array
  {
   min=input[n];
  }

  if(max<input[n]) // finding the largest element in the array
  {
  max=input[n];
  }
 
  n++;
 }

 avg=avg/length;   // here we are finding average of the given input numbers;

 result[0] = (float)min;  // sice the variable min and max are of type integer hence, we are doing explicit type casting
 result[1] = avg;
 result[2] =(float)max;
}

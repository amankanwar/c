/*Q7. Implement a C program, where is a=10,b=20,c=30 evaluate the
following
d=++a,++b,++c,a+5;
d=(++a,++b,++c,a+5);
*/

#include<stdio.h>

int main(void)
{
   int a=10,b=20,c=20,e;
   
   int d=(++a,++b,++c,a+5);

  
    printf("Inputs are A: %d B: %d C: %d",a,b,c);

    e=++a,++b,++c,a+5;
 
    printf("Value of \n\n\te=++a,++b,++c,a+5;\n\n is d=%d",e);

    printf("\n\nHere the value of the operand on the right side of the assignment operator is assigned to the operand on the left side of the assignment operator");
  
    printf("\n\nSimilarly\n\nValue assigned to d in Expression\n\n d=(++a,++b,++c,a+5);\n will be d= %d",d);

    printf("\n\nHere since there is an expression enclosed within the () on the right hand side of the operator, hence the value of last expression a+5 is assigned to the variable d");
	return  0;
}

//
//Q4. Implement a C program to find out biggest of 3 no.s using
//conditional operator.
//
#include<stdio.h>

int main()
{ 
	int n1,n2,n3;

	int largest;

	printf("\n\nThis program finds the biggest of there numbers");

        printf("\n\tNumber1: ");
	scanf("%d",&n1);
	printf("\n\tNumber2: ");
	scanf("%d",&n2);
	printf("\n\tNumber3: ");
        scanf("%d",&n3);
	
        largest=  (n1>n2)?((n1>n3)?(n1):(n3)) : ((n2>n3)?(n2):(n3));

	printf("\nLargest Number is %d\n\n",largest);

	return 0;
}

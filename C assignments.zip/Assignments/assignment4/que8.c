//Q8. Write a program to count no. of 1s or no. of 0's in a binary code.I

#include<stdio.h>

void ones_zeros(long long unsigned int);


int main()
{
  long long unsigned int input;

  printf("Please enter a binary number\n\nBinary Num: ");
  scanf("%lld",&input);
  printf("input: %lld",input);
  
  ones_zeros(input);
  return 0;  
}

void ones_zeros(long long unsigned int input)
{
 int o=0,z=0,val;
long long unsigned int n=input;

 if(n==0)
 {
 z++;
 }
 else if(n==1)
 {
 o++;
 }
 
 else if(n>1)
 {

 while(n!=0)
 {
  val=n%10;
  
  if(val==0)
  {
  ++z;
  }
  else if(val==1)
  {
  ++o;
  }
  n=n/10;
 }

 }

 printf("\n\nZeroes: %d Ones: %d",z,o);
}

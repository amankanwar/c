//Q7. Write a program Number format conversions(decimal, binary and
//octal)
//
#include<stdio.h>

int binary(long long unsigned int,int*);

int main(void)
{
 long long unsigned int input;
  int bin[200];
  printf("\n\nPlease enter the number to convet\n\nNumber: ");

}

int binary(int input,int *bin)
{
 long long unsigned int val=input;
 int bit,pos=0;
 
 if(input==0 || input ==1)
 {
  bin[pos]=input;
  pos++;
  return pos;
 }

 while(val!=0)
 {
   bit=val%2;
   val/=10;
   bin[pos]=bit
   pos++;
 }

}


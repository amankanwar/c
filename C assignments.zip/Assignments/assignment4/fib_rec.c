//this code will print the fibnocci series with the array implementation
//
#include<stdio.h>

void fib(int);

int main(void)
{
  int length,a;
  printf("Please enter the list length");

  scanf("%d",&length);

  fib(length);
  
return 0;
}

void fib(int n)
{
  static int k=1,i=0,sum=0;
  if(n==1)
  {
   printf("%d\n",sum);  
  }
  else{
       	  printf("%d ",sum);
	  i=k;
	  k=sum;
	  sum=i+k;
	  fib(n-1);
  }
          
}

//Q8. Write a program to count no. of 1s or no. of 0's in a binary code.
// we will implement recusrion in this code
#include<stdio.h>
//------------------------------------------------------------------
int *bin_cal(long long unsigned int,int *);                      //|
//------------------------------------------------------------------
int main(void)
{
 long long unsigned int input;
 int val[2]={0};
 printf("\n\nPlease enter the number\n Nunber: ");
 scanf("%lld",&input);
 bin_cal(input,val);
 printf("\n\nNumber of zeros: %d  Ones: %d\n\n",val[0],val[1]);
}
//-------------------------------------------------------------------
int *bin_cal(long long unsigned int input,int *val)
{
 long long unsigned int num=input;
 int remainder;
 if(num==0 || num==1)
	 ++val[num];
 else
 {
 remainder=input%10;
 ++val[remainder];
 return(bin_cal(input/10,val));
 }
}
//-------------------------------------------------------------------

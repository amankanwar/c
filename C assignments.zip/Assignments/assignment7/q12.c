/*Q 12. Passing function names as parameters
void test(int x, int y, int (*fp) (int,int))
{
int z = fp(x,y);
----
}
test(10,20,sum);   */

#include<stdio.h>
#include<stdlib.h>

//---Function Declarations

int add(int,int);   
int sub(int,int);

int calculate(int,int (*p)(int,int),int);   //using int *fp(int,int) will cause an error, since compiler may handle that incorrectly

//______________________________________________________________________________________________________________________

int main(void)
{
//-------Declarations---------
 int num1=10,num2=12,result=0,choice;

 // using "typedef int *fp(int,int);"

 //  this will cause an error 
 //  error: lvalue required as left operand of assignment
 //  add_fp  = add;                   // assigning the address of the function add(int,int)
 //  since compiler will take the expression "typedef int *fp(int,int);" as fp is a function returning pointer. Hence, correct approach will be
 
typedef int (*fp)(int,int);  //  using () around the identifier is necessary in this condition


 fp add_fp, sub_fp;               //created two pointers to the of type pointer to a function having two parameters and integer return type

 add_fp  = add;                   // assigning the address of the function add(int,int)
 sub_fp  = sub;                   // assigning the address of the function sub(int,int)
//---------------------------

//------Menu screen---------
 system("clear"); 


//result =  add_fp(num1,num2);

printf("\n\n\t\t\tPlease select the given operation: Add:--1  Subtract:--2"); 

 result = calculate(num1,add,num2);
 
 printf("\n\n\t\tResult of operation is %d\n\n",result);

	 return 0; 
}

	int add(int num1, int num2)
	 {return(num1+num2);}
	 
	int sub(int num1, int num2)
	{return(num1-num2);}

// this function will take another function as its parameter
	
	int calculate(int num1, int (*ptr)(int,int), int num2)
 	{
         int result = ptr(num1,num2);
	 return result;
	}

/////////////////////////////////////////////////////////////

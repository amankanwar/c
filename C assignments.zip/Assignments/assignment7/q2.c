// Q2. Try register storage class for local, global variables. Can we get
//address of register variable
//
#include<stdio.h>

int main(void)

//register int global_var = 10;

{
 register int local_var = 20;
  
 printf("\n\nThe local Variable : %d",local_var);
// printf("\n\nThe global Variable is : %d",global_var);

 printf("\n\nAddress of register local variable is %p",&local_var);
//this will given an error since the complier is having the access to the memory address persent in the Ram which is the main memory of the enviroment
//and the register class is not having any dedicated address for the CPU registers. Hece it is impossible to gather the address of a given register inside the CPU


//-------- Error Message-----------------------------------------------
//error: address of register variable ‘local_var’ requested
//  printf("\n\nAddress of register local variable is %p",&local_var);
//----------------------------------------------------------------------
/*

In theory, you could allocate a processor register to a global scope variable - that register would simply have to remain allocated to that variable for the whole life of the program.

However, C compilers don't generally get to see the entire program during the compile phase - the C standard was written so that each translation unit (roughly corresponding to each .c file) could be compiled independently of the others (with the compiled objects later linked into a program). This is why global scope register variables aren't allowed - when the compiler is compiling b.c, it has no way to know that there was a global variable allocated to a register in a.c (and that therefore functions in b.c must preserve the value in that register).
*/

// printf("\n\nAddress of register global variable is %p",&global_var);

// hence, this will given an error

 return 0;
}

/*Q10. Function Pointers
-Write a simple program to test function pointer
-Typedef for function pointer
typedef int (*pftype)( );
pftype pf1;
(or) typedef int (*pftype)(int, int); */

//---------- In this code we have tested, the array of function pointers and we will call the function pointer using array elements
//
//---------- fun_arr[](para1,para2);



#include<stdio.h>

int add(int, int);   // this is normal function which takes two parameter and performs addition to the given function and returns the sum of the same.

int main(void)
{
       	
int result=0;

//---------------Normal Approach, using the function call to the given function and passing the parameter to the given function

result = add(10,10);
printf("\n\nResult using normal approach add(10,20) is  %d\n\n",result);

//------- Condition 1 pointer to a given function, normal approach -------------------
int (*pointer_to_add_function[2])(int,int); // fp is pointer to a function which takes 2 parameters and returns an integer (fp is a function pointer)
//pointer_to_add_function = add;            //assigning the address of add function to the function pointer fp
//result = pointer_to_add_function(10,20);
//printf("\n\nResult using pointer_to_add_function(10,20) is  %d\n\n",result);
//------------------------------------------------------------------------------------


pointer_to_add_function[0] = add; //contributed by abdul

pointer_to_add_function[1] = add; //contributed by abdul 

result = pointer_to_add_function[0](1,2);

printf("\n\nResult using pointer_to_add_function(10,20) is  %d\n\n",result);

/*


//--- condition 2 using the "typedef" implementation in the given function to create a pointer to the given function and treat the given pointer as function

typedef int (*function_pointer)(int,int);

// now the given keyword "funciton_pointer" will itself act as a datatype wherein using the statement:  function_pointer fptr;
// this will create a new variable "fptr" of type "pointer to a function which takes two integer variable and returns an int"

function_pointer ptr1,ptr2;    // here two variables are created of type function pointer (as mentioned in above comment)

//---------------------------------------------------------------------------------------------------------------------------------------------

// here the ptr1 and ptr2 are the data type of type function pointer which accepts two paramater of integer and returns an int
// Hence, we may use the given pointers as similar to the given function

ptr1 = add;

ptr2 = add;

result  = ptr1(20,30);
printf("\n\nNew result with ptr1(20,30) is  %d",result);

result = ptr2(30,40);
printf("\n\nNew result with ptr2(30,40) is %d\n\n",result);


*/

return 0;
}

// this is function for which we will make function pointers and implement the same using the typedef statement to create user-defined declaration

int add(int a, int b)
{
return (a+b);
}

//Q1. Write a program to find how many times a function is being called
//(use local static variable as count)
//
#include<stdio.h>

int called_function();

int main()
{
	int count=0;
	// creating function calls
	called_function();
	called_function();
	called_function(); 
	called_function();

	count =	called_function();

printf("Function was called %d times\n\n",count);

return 0;}

int called_function()
{
 static int count = 0;
 return(++count);
}

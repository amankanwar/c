/*Q10. Function Pointers
-Write a simple program to test function pointer
-Typedef for function pointer
typedef int (*pftype)( );
pftype pf1;
(or) typedef int (*pftype)(int, int); */

//Auther: Aman Kanwar

// Updates: In this code we have implemented a menue driver program, wherein the user may select the option to execute the given dedicated funciton
// based on the input of the user. Also we are not using any if, else, switch statement
// 
// Here we will implement the usage of function pointer which is stored in the given array.

#include<stdio.h>
#include<stdlib.h>

//-------Function prototypes-----------------------------------------------------------------------------

int add(int, int);   // this is normal function which takes two parameter and performs addition to the given function and returns the sum of the same.

int sub(int, int);  // this function perfoms substraction of the given input numbers and returns the result for the same.

int mul(int, int);  // this function performs the multiplication of the given input number and returns the result for the same.

int power(int, int);
//------------------------------------------------------------------------------------------------------



int main(void)
{
       	
//---Clearing the screen--------
system("clear");
//-----------------------------

//-----Declarations-----------
int num1=0,num2=0,result=0;
short int selection=0;
int(*fp[4])(int,int);           // array of function pointers
//-----------------------------


//-------typedef approach-----------
/* 

typedef int (*fp)(int,int);   // creating a new datatype of type fp which is a "pointer to a function with two variables and returns an int"

fp calculation[4];            // using 'fp' as a userdefined data type, creating an array named calculation[4], consisting of 4 function pointer

calculation[0]= add;
calculation[1]= sub;
calculation[2]= mul;
calculation[3]= power;


result = calculation[selection](num1,num2);
*/

//---- Function Pointer Initialization----

//---------------------------------------------------------------------------------------------------
//---Assigning the address of the functions to the given array members
//---Note that the given array is the array consisting of pointers to a function which takes two variables and return an integer
fp[0]= add;
fp[1]= sub;
fp[2]= mul;
fp[3]= power;
//---------------------------------------------------------------------------------------------------


//###########################Start Up Menue #############################################
printf("\n\n\t\t############ Function Call using function Pointer ######################");
printf("\n\n\t\t\t=======>Please Choose from the given menu<==========");
printf("\n\n\n\t1: Addition\t\t\t2: Substraction\n\t3: Multiplication\t\t4: Power Num1^Num2\n\n\tSelection: ");
scanf("%hd",&selection);
//#######################################################################################

//--------- User Inputs -------------
printf("\n\n\t\tNumber1: ");
scanf("%d",&num1);
printf("\n\t\tNumber2: ");
scanf("%d",&num2);
//----------------------------------	

selection--;                           // to arrange the inputs in the range of function pointers stored in fp

//----Based on input, initiating a function call for the given function
result = fp[selection](num1,num2);
// using typedef
// result = calculation[selection];
//-----------------------------------------------------------------------------------------


//displaying the output

printf("\n\nResult of the selected operation on Num1: %d, Num2: %d is =  %d\n\n",num1,num2,result);
return 0;
//--------------------
}

// this is function for which we will make function pointers and implement the same using the typedef statement to create user-defined declaration

//--------Function to Add-----------
int add(int a, int b){return(a+b);}
//--------Function to sub-----------
int sub(int a, int b){return(a-b);}
//--------Function to mul-----------
int mul(int a, int b){return(a*b);}

//--------Function to power---------
int power(int a, int b) 
{
	int res=1;
	while(b--!=0){res= res * a;}	
        return(res);
}

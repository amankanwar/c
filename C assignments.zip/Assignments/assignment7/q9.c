/*Q9. Can you return arrays from a function
(a) base address
(b) whole array
*/

#include<stdio.h>

int (*array_return(void))[5];    // declaration of a function named, array_return is a function which returns pointer to an array of 5 integers

int *base_return(void);          // base_return is a function which return the base address of a given array present in the function


int main(void)
{

int(*array_ptr)[5];             // declaring pointer, array_ptr is a pointer to an array of 5 integers
int *array_base_ptr;            // array_base is a pointer to an integer

array_ptr = array_return();     // array address returned by the given function call
array_base_ptr = base_return(); // base address of the array is returned by the given function

printf("Address of complete array1 is %p\n\nAddress of Base address of array2 is %p\n\n",array_ptr,array_base_ptr);
return 0;
}

int (*array_return(void))[5]   // function definition of array_return function which returns pointer to an array of 5 inegers
{
 static int arr[5]= {10,12,14,16,18};
 return &arr;
}

int *base_return(void)         // function definition to a function which returns pointer to an integer
{
	static int arr2[5]={1,2,3,4,5};
	return arr2;
}

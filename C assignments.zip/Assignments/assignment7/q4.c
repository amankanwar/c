//Q4. Write a function to swap two variables using Pass by value, Pass by reference
//
#include<stdio.h>
#include<stdlib.h>

void swap(int* , int*);

int main(void)

{
 system("clear");	
 int number1,number2;

 printf("Number 1: ");
 scanf("%d",&number1);

 printf("Number 2: ");
 scanf("%d",&number2);

 swap(&number1,&number2);

 printf("\n\n\n\t\tNumber 1: %d",number1);
 printf("\n\n\n\t\tNumber 2: %d\n\n",number2);

return 0;
}

void swap(int *p1, int *p2)
{
 *p1 = *p1 + *p2;
 *p2 = *p1 - *p2;
 *p1 = *p1 - *p2;
}

//Q6. Whats wrong in this code, any fixes to the problem?
/*
int* test(int x)
{
int y=x*x;
return &y;
}
*/


#include<stdio.h>
#include<stdlib.h>


int *test(int x)
{
//static int y;       // this will work but it is not relaible
//y=x*x;
int y=x*x;
return &y;
}

int main(void)
{
  system("clear");
  
  int val=0;

  int  *p= NULL;

  printf("Enter Number: ");
  scanf("%d",&val);

  p = test(val);
   
  printf("\n\n\n\t\tOperation done on the given Variable %d is, %d\n\n\t\t\t===>Press Enter to Know the issue<===",val,*p);

   // error will be Segmentation fault (core dumped)
 
   
  getchar();
  getchar();

  system("clear");

  printf("\n\t\t\t Here the issue is with the return type of the function -->int* test(int x)<--\n\t\t\tWherein the given function is returning the address of its local variable\n\t\t\tSince the scope of a local variable is within a given function block, hence, it is not recommended to return the address of a local variable\n\t\t\tHowever, this program may gentrate assumed output for some compilers but it is not a good practive to return address of local variable\n\n");


  // error from the code warning: function returns address of local variable [-Wreturn-local-addr]
  // return &y;



return 0;
}

//Q5. Write a single function to return sum, product of two no.s
//
#include<stdio.h>
#include<stdlib.h>


int *operation(int, int,int *);

int main(void)
{
 system("clear");
 int num1,num2;
 int result[2]={0};   // result[0] = sum, result[1]= product
 int *res;


 printf("\n\n\t\tNumber1: ");
 scanf("%d",&num1);

 printf("\n\t\tNumber2: ");
 scanf("%d",&num2);

 res = operation(num1,num2,result);
 
 printf("\n\t\tSum of Number is %d, product of number is %d\n\n",result[0],result[1]);

return 0;


}

int *operation(int num1, int num2, int *res)
{
  res[0]=num1+num2;
  res[1]=num1*num2;
  return(res);
}

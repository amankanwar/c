//Q3. Try some nested calls sqrt(pow(2,abs(x))), putchar(toupper(ch)) etc



#include<stdio.h>      // to implement the stdin library
#include<math.h>       // to include the math function pow(), pow()
#include<stdio_ext.h>  // to implement the function __fpurge(stdin)
#include<stdlib.h>     // to implement the fucntion abs(number), absolute of a given number 
#include<ctype.h>      // to implement the function toupper(number), this will convert the character to the upper case


int main(void)
{
float result=0;
int number;
char input='\0';

printf("\n\n\n\t\t\tImplementation of sqrt(pow(2,abs(number)))");
printf("\n\n\n\t\tPlease enter the Number: ");
scanf("%d",&number);

result = (float)sqrt(pow(2,abs(number)));

printf("\n\n\t\tValue of sqrt(pow(2,abs(x))) is %f\n\n",result);

__fpurge(stdin);            // clearing the buffer

printf("\n\n\n\t\t\tImplementation of putchar(toupper(ch))");
printf("\n\n\t\tPlese Enter the Character to Convert to Upper Case: ");
scanf("%c",&input);

printf("\n\nConverted Character is: ");

putchar(toupper(input));

puts("");
return 0;
}

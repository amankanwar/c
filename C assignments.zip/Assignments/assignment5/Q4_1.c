//Q4. WAP for Addition, Subtraction, Multiplication of two matrices
//
//In this code we will implement the metrics creation by implementing the memory allocation in order to save some memory
//further, the Idea here is to take a double pointer to an integer and then allocating memory to the double pointer first
//then allocating memeory (in order to create colums) to the single pointer location present at every index on the  array of pointers created by the 
//previus double pointer.
//Furhter, I have implemented the calloc technique in order to have the metrics initialized at zero (for ever element[i][j])
//
//Version:             V4_1 
//Fixes:               Fixed the memory leakage present in the previous version of this code.  
//New Implementations: 
/*Added a function to display the metrics data and a new function to free the allocated memory space which were allocated in the code space  


*/
//----------------------------------------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------------------------------------

#include<stdio.h>
#include<stdlib.h>

//-------------For new metrics creation-------------------
int ** return_x_y_metrics(int *);
//--------------------------------------------------------

//----For input form the user for the given metrics ------
void user_input_array(int **,int*);
//--------------------------------------------------------

//----To show the data input by the user------------------
void display_metrics(int **, int *);
//--------------------------------------------------------

//----------For addition of metrics--------------
int **return_addition(int **, int **, int *, int *);
//----------------------------------------------

//-------------------------------------------------------------
void freed_memory(int **, int **,int **,int *);
//--------------------------------------------------------------
	
//TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
//TTTTTTTTTTTTTTTTTTTTTTT Main Function  TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
//TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT

int main(void)  //============= Main Function ==============
{

//------Declatations---------	
 int **metrics1       =NULL;
 int **metrics2       =NULL; 
 int **result_metrics =NULL;

 int size_m1_xy[2]={0,0};
 int size_m2_xy[2]={0,0};
//--------------------------

 metrics1 = return_x_y_metrics(size_m1_xy);
 user_input_array(metrics1,size_m1_xy);

 printf("\n\nSecond Metrics\n\n");

 metrics2 = return_x_y_metrics(size_m2_xy);
 user_input_array(metrics2,size_m2_xy);

  printf("\n\n\t\tMetrics 1\n\n");
  display_metrics(metrics1,size_m1_xy);


  printf("\n\t\tMetrics 2\n\n");
  display_metrics(metrics2,size_m2_xy);

  result_metrics = return_addition(metrics1, metrics2, size_m1_xy, size_m2_xy);
 
  printf("\n\nAfter Addition of metrics1 and metrics2, we have new metrics\n\n");

  display_metrics(result_metrics,size_m2_xy);

//############## For testing only ########## 
/*   for(int i=0; i<size_m1_xy[0]; i++)
   {
     for(int j=0; j<size_m1_xy[1]; j++)
     {
            metrics1[i][j]=j; 
	    printf("%5d", metrics1[i][j]);
     
     }
     printf("\n\n"); 
     } */
//##########################################   

freed_memory(metrics1,metrics2,result_metrics,size_m1_xy);

return 0;
}
//TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
//TTTTTTTTTTTTTTTTTTTTTTT END  TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
//TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT

//#################### No Modification Required in this fucntion ########################################
//###### This function creates new metrics and returns its address and size of row and column ###########
//#######################################################################################################
int ** return_x_y_metrics(int *size)
{
//----------------------Declarations----------------------------------------------	
  int rows=0,column=0;
  int **create_metrics=NULL;
//--------------------User Inputs-----------------------------------------------  
 
  // here we will will appy a condition wherein if the size of the array is not provided as parameter then the given
  // code provided below will request the user to enter the size of rows and colums, if the size of array is provided
  // (for a case another function is accessing this function to store result) then size of array will be provided as
  // parameter by that calling funtion and we just need to implement a condition wherein if the size is zero then as
  // the user for size, if the size is not zero then use that given size  size[0] = row  size[1]= column


  if(size[0] == 0 && size[1] == 0)
  {	  
  printf("Please enter the Size of the Metrics in the Format Row and Columns");
  printf("\n\nRows  : ");
  scanf("%d",&rows);
  printf("\nColumn: ");
  scanf("%d",&column);

  // now we will assign the size of rows and column to the memory location we have received from the calling function
  size[0]=rows;       
  size[1]=column;
  }

  else   // if the input is already having the input value of rows size[0] column size[1]
  {
  
	  printf("size of row: %d   size of coulmn= %d",size[0],size[1]);
          rows    = size[0];   // copying the alrady provided value of rows and columns passed by the addition function
	  column  = size[1];  
  }

	  // size provided during function call will be used automatically
	  
//-------------------------------------------------------------------------------

//--------------------Need No modification------------------------------------------  
 
// here we are creatig an arry of pointers with size of each element equal to the size of int pointer :- sizeof(int *)
 

  create_metrics = (int **)calloc(column,sizeof(int*));   // creating array of pointers
  
  //_______Checking for NULL__________
  if(create_metrics == NULL)
  {
  printf("Memory Allocation for columns failed");
  }
  //__________________________________
 
// Now we are assigning address to each pointer to int, with memory location size equal to number of rows * sizeof(int) to each int pointer of the previous array.

  for(int i=0;i<rows;i++)
  {  
    create_metrics[i]=(int *)calloc(rows,sizeof(int));   //creating memory locations for int pointers (which belong to the array of pointers)
                //__________________Checking for NUll ___________________
    	 	if(create_metrics[i] == NULL)
        	 {
  	           printf("Memory ALlocation for rows failed failed");
 		 }
		//________________________________________________________
  }
//------------------------------------------------------------------------------------

//XXXXXXXXXXXXXXXXXXXXX   Only for Testing   XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/*  
  printf("\nAddress of memeory allocated2: %p\n\n",*create_metrics);
   
   for(int i=0; i<rows; i++)
   {
    for(int j=0; j< column; j++)
    {
            create_metrics[i][j]=j; 
	    printf("%5d", create_metrics[i][j]);
     
    }
    printf("\n"); 
   }
*/ 
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
   return create_metrics;
}
//####################################################################################################
//####################################################################################################



//#################### No Modification Required in this fucntion #####################################################
/*In this function we are taking inputs from the user for the given array element 
 *Once the inputs are complete the function returns a true (1) to the calling function or else a zero is returned*/   
//####################################################################################################################
 void user_input_array(int **metrics_name, int *size_m_xy)
 {
    printf("\n\n\t\t\tPlease enter the data in the metrics carefully!!!");
   
        for(int row=0; row<size_m_xy[0]; row++)
 	{
          for(int column=0; column<size_m_xy[0]; column++)
           {
             printf("\nElement[%d][%d]: ",row,column);
	     scanf("%d",&metrics_name[row][column]);
	   }      
	}
      
    printf("\n\n\t\t\tMetrics Sumbitted Successfully\n\n");
    
    display_metrics(metrics_name,size_m_xy);      // displaying the input data  
 }
//####################################################################################################################
//#######################################################################################################



//#################### No Modification Required in this fucntion ########################################
/* This function takes 3 metrics as parameter, 
 * add them and store the result in new metrics,
 * after addition it returns address of newly created metrics and size of row and column*/ 
//#######################################################################################################
int **return_addition(int **metrics1, int **metrics2, int *size_m1_xy, int *size_m2_xy)
{
 int **new_metrics;  // creating pointer for a new metrics

       if(size_m1_xy[0]==size_m2_xy[0] && size_m1_xy[1] == size_m2_xy[1]) // check if the size of metrics is same	 
 	{
		 // is the condition is true then both the size of metrics1 and metrics2 are same.
		 // hence, we may pass the size of any of the metrics1 or metrics2 as parameter to create the new metrics

         new_metrics = return_x_y_metrics(size_m1_xy);

		 // new metrics is created with the required size of the previous metrics and all of the metrics elements are initialized to zero

 	} 
	 
        else // if the size of the metrics is not equal then the metrics will not be added together
	 {
	    return NULL; // metrics can not be added
	 }

	printf("\n\n\nwe are here");
 //--------------------------Adding Metrics-----------------------------------------------------
    for(int row=0; row<size_m1_xy[0]; row++)
	{
           for(int column=0; column< size_m1_xy[1]; column++)
              {
                new_metrics[row][column] = metrics1[row][column] + metrics2[row][column];
	      }
	}
//----------------------------------------------------------------------------------------------

 return new_metrics;
}
//#########################################################################################################
//#########################################################################################################


//#################### No Modification Required in this fucntion ########################################
/*This function simply show the result for the given metrics on the basis of the size provided by the 
calling function. 
 *This function takes 1 metrics as parameter, and an integer array containing size of metrics  */   
//#######################################################################################################
void  display_metrics(int **metrics, int *size_m_xy)
{
   for(int i=0; i<size_m_xy[0]; i++)
   {
    for(int j=0; j<size_m_xy[1]; j++)
    { 
	    printf("%5d", metrics[i][j]);     
    }
    printf("\n"); 
   }
}
//#######################################################################################################
//#######################################################################################################


void freed_memory(int **metrics1, int **metrics2, int **metrics3,int *size_m_xy)
{
  
  for(int i=0;i<size_m_xy[0]; i++)
  {
	free(metrics1[i]);  // free memmory from columns
	free(metrics2[i]);  // free memory from  columns
	free(metrics3[i]);  // free memory from columns
  }
  
	free(metrics1);    // free memory from rows
	free(metrics2);    // free memory from rows
	free(metrics3);    // free memory from rows
}

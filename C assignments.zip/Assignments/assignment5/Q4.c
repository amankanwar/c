//Q4. WAP for Addition, Subtraction, Multiplication of two matrices
//
//In this code we will implement the metrics creation by implementing the memory allocation in order to save some memory
//further, the Idea here is to take a double pointer to an integer and then allocating memory to the double pointer first
//then allocating memeory (in order to create colums) to the single pointer location present at every index on the  array of pointers created by the 
//previus double pointer.
//Furhter, I have implemented the calloc technique in order to have the metrics initialized at zero (for ever element[i][j]
//
//
#include<stdio.h>
#include<stdlib.h>

//-------------For new metrics creation-------------------
int ** return_x_y_metrics(int *);
//--------------------------------------------------------

//----For input form the user for the given metrics ------
int user_input_array(int **,int*);
//--------------------------------------------------------

//----------For addition of metrics--------------
int **return_addition(int **, int **, int *);
//----------------------------------------------

int main(void)  //============= Main Function ==============
{

//------Declatations---------	
 int **metrics1;
 int **metrics2; 
 int **result_metrics;

 int size_m1_xy[2]={0};
 int size_m2_xy[2]={0};
//--------------------------

 metrics1 = return_x_y_metrics(size_m1_xy);
 
 user_input_array(metrics1,size_m1_xy);
 


//############## For testing only ########## 
/*   for(int i=0; i<size_m1_xy[0]; i++)
   {
     for(int j=0; j<size_m1_xy[1]; j++)
     {
            metrics1[i][j]=j; 
	    printf("%5d", metrics1[i][j]);
     
     }
     printf("\n\n"); 
*/   }
//##########################################   

return 0;
}

//#################### No Modification Required in this fucntion ########################################
//###### This function creates new metrics and returns its address and size of row and column ###########
//#######################################################################################################
int ** return_x_y_metrics(int *size)
{
//----------------------Declarations----------------------------------------------	
  int rows=0,column=0;
  int **create_metrics;
//--------------------User Inputs-----------------------------------------------  
 
  // here we will will appy a condition wherein if the size of the array is not provided as parameter then the given
  // code provided below will request the user to enter the size of rows and colums, if the size of array is provided
  // (for a case another function is accessing this function to store result) then size of array will be provided as
  // parameter by that calling funtion and we just need to implement a condition wherein if the size is zero then as
  // the user for size, if the size is not zero then use that given size  size[0] = row  size[1]= column
  
  if(size[0] == 0 && size[1] == 0)

  {	  
  printf("Please enter the Size of the Metrics in the Format Row and Columns");
  printf("\n\nRows: ");
  scanf("%d",&rows);
  printf("\nColumn: ");
  scanf("%d",&column);

  // now we will assign the size of rows and column to the memory location we have received from the calling function
  size[0]=rows;       
  size[1]=column;
  }

  else
	  // size provided during function call will be used automatically
	  
//-------------------------------------------------------------------------------

//--------------------Need No modification------------------------------------------  
 
// here we are creatig an arry of pointers with size of each element equal to the size of int pointer :- sizeof(int *)
 
  create_metrics = (int **)calloc(column,sizeof(int*));   // creating array of pointers
  
  //_______Checking for NULL__________
  if(create_metrics == NULL)
  {
  printf("Memory Allocation for columns failed");
  }
  //__________________________________
 
// Now we are assigning address to each pointer to int, with memory location size equal to number of rows * sizeof(int) to each int pointer of the previous array.

  for(int i=0;i<rows;i++)
  {  
    create_metrics[i]=(int *)calloc(rows,sizeof(int));   //creating memory locations for int pointers (which belong to the array of pointers)
                //__________________Checking for NUll ___________________
    	 	if(create_metrics[i] == NULL)
        	 {
  	           printf("Memory ALlocation for rows failed failed");
 		 }
		//________________________________________________________
  }
//------------------------------------------------------------------------------------

//XXXXXXXXXXXXXXXXXXXXX   Only for Testing   XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/*  
  printf("\nAddress of memeory allocated2: %p\n\n",*create_metrics);
   
   for(int i=0; i<rows; i++)
   {
    for(int j=0; j< column; j++)
    {
            create_metrics[i][j]=j; 
	    printf("%5d", create_metrics[i][j]);
     
    }
    printf("\n"); 
   }
*/ 
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
   return create_metrics;
}
//####################################################################################################

//_____________________________________________________________________________________________________________________________________________________________________

//#################### No Modification Required in this fucntion #####################################################
/*In this function we are taking inputs from the user for the given array element 
 *Once the inputs are complete the function returns a true (1) to the calling function or else a zero is returned*/   
//####################################################################################################################
 int user_input_array(int **metrics_name, int *size_m_xy)
 {
   printf("\n\n\t\t\tPlease enter the data in the metrics carefully!!!")
   
        for(int row=0; row<size_m_xy[0]; row++)
 	{
          for(int column=0; column<size_m_xy[0]; column++)
           {
             printf("Element[%d][%d]: ");
	`    scanf("%d",&metrics_name[row][column]);
	   }      
	}
      
    printf("\n\n\t\t\tMetrics Sumbitted Successfully\n\n");
    
    return(display_metrics(metrics_name,size_m_xy));      // displaying the input data     
 }
//####################################################################################################################

//_____________________________________________________________________________________________________________________________________________________________________

//#################### No Modification Required in this fucntion ########################################
/* This function takes 3 metrics as parameter, 
 * add them and store the result in new metrics,
 * after addition it returns address of newly created metrics and size of row and column*/ 
//#######################################################################################################
int **return_addition(int **metrics1, int **metrics2, int *size_m1_xy, int *size_m2_xy)
{
 int **new_metrics;  // creating pointer for a new metrics

       if(size_m1_xy[0]==size_m2_xy[0] && size_m1_xy[1] == size_m2_xy[1]) // check if the size of metrics is same	 
 	{
		 // is the condition is true then both the size of metrics1 and metrics2 are same.
		 // hence, we may pass the size of any of the metrics1 or metrics2 as parameter to create the new metrics

         new_metrics = return_x_y_metrics(size_m1_xy);

		 // new metrics is created with the required size of the previous metrics and all of the metrics elements are initialized to zero

 	} 
	 
        else // if the size of the metrics is not equal then the metrics will not be added together
	 {
	    return null; // metrics can not be added
	 }

 //--------------------------Adding Metrics-----------------------------------------------------
    for(int row=0; row< size_m1_xy[0]; row++)
	{
           for(int column=0; column< size_m1_xy[1]; column++)
              {
                new_metrics[row][column] = metrics1[row][column] + metrics2[row][column];
	      }
	}
//----------------------------------------------------------------------------------------------

 return new_metrics;
}
//#########################################################################################################
//#########################################################################################################


//#################### No Modification Required in this fucntion ########################################
/*This function simply show the result for the given metrics on the basis of the size provided by the 
calling function. 
 *This function takes 1 metrics as parameter, and an integer array containing size of metrics  */   
//#######################################################################################################
int display_metrics(int **metrics, int *size_m_xy)
{
   for(int i=0; i<size_m_xy[0]; i++)
   {
    for(int j=0; j<size_m_xy[1]; j++)
    { 
	    printf("%5d", metrics[i][j]);     
    }
    printf("\n"); 
   }

  return 1;
}
//#######################################################################################################



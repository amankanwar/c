// this code will create a student grading system based on the markes that the sudents have acheived
//
#include<stdio.h>
#include<string.h>

int find_grade(int);

int main(void)
{
int i,total=0,grade;
int marks[5];
char *subjects[5]={
 "Physics",
 "Chemistary",
 "Matematics",
 "Biology",
 "Computers"
};

printf("Please Enter the marks of the given corresponding subjects");

for(i=0;i<5;i++)
{
printf("\n\t\t\t%s:- ",subjects[i]);
again:
scanf("%d",&marks[i]);

      if(marks[i]>=0 && marks[i]<=100)
      {
      total=total+marks[i];
      }
      else
      {
	      printf("\nInvalid Marks, enter again");
	      goto again;
      }
}

printf("\n\nTotal= %d\n\n",total);
grade=find_grade(total);

printf("Grade of the Sudent is %d grade",grade);
return 0;
}

int find_grade(int total)
{
int grade;
grade=((total*100)/500);

printf("\n\npercentage= %d\n\n",grade);

if(grade>35 && grade<=50)
{
return 3;
}
else if(grade>51 && grade<=64)
{
return 2;
}
else if(grade>65)
{
return 1;
}
else
{
printf("Invalid result");
}
return 0;
}

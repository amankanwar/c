#include<stdio.h>
#include<string.h>

float exemption(char,char,int,unsigned int);

float tax_calculation(unsigned int);

int main(void)

{
  char name[20];
  char gender;
  int age;
  unsigned int income;
  char investment_status='n';
  float tax_total=0;
	
 printf("Tax Calculation, Please enter the details carefully");
  
 printf("\n\nName: ");
 scanf("%s",name);
 getchar(); 
//getchar();
 printf("\nGender: ");
 scanf("%c",&gender);
 printf("\nAge: ");
 scanf("%d",&age);
 printf("\nIncome: ");
 scanf("%d",&income);
 getchar();
 printf("\nInvestment in Govt. Programs? Y-- Yes  N--No\n\n\tInput: ");
 scanf("%c",&investment_status);
 tax_total=tax_calculation(income)-exemption(gender,investment_status,age,income);

 printf("\n\n\t\t===Total Calculated tax is ₹%.2f===\n\n\n",tax_total);
}

float tax_calculation(unsigned int income)
{
        float tax=0;
	tax= (((12.5*income)/100));
	return tax;
}

float exemption(char gender, char response, int age, unsigned int income)
{
  float discount=0;
  
  if(age>55 && age<100)
  {
   if(gender=='f'|| gender =='F' || gender=='M' || gender == 'm')
   {
	   if(income>100000 && income<=500000)
	   {
	    if(response=='y' || response =='Y')
	    {
	     return(((2*income)/100)+5000); 
	    }   
	    else
		    return(((2*income)/100));
	   }

	   else if(income <=100000)
	   {
	    if(response=='y' || response =='Y')   
	     {
             printf("\nNo tax is applicable\n");
	     return (((12.5*income)/100));
	     }
             else
		     return (((4*income)/100));
	   }
	   else if(income>500000)
	   {
	    if(response=='y' || response =='Y') 
	    {
	     return (((1.5*income)/100)+10000);
	    }
	    else
		    return (((1.5*income)/100));
	   }
   }
  }

  else if(age<50)
  {
    if(income>500000)
    {
    if(response=='y' || response =='Y')
      {
       return (((2.5*income)/100)+10000);
      }
    else
	    return (((2.5*income)/100));
    }
    
    else if(income <=500000)
    {
    if(response=='y' || response =='Y')
      {
       return (((3.5*income)/100)+10000);
      }
    else 
	    return (((2.5*income)/100));
    }
   
  }

}

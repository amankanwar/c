// this program prints the Fibnocii series 0 1 1 2 3 5 8
//
#include<stdio.h>

int fib(int num);

int main(void)
{
 int input,output;
 printf("\n\nPlease Enter the range upto which Fibnocii series is to be printed\n\nNumber: ");
 
 scanf("%d",&input);
 
output= fib(input);

 printf("%d",output);
}

int fib(int num)
{
  if(num==0 || num==1)
  {
	return num;
  }
  else
  {  
    return (fib(num-1)+fib(num-2));
  }
  return 0;
}  

#include<stdio.h>

int add(int,int);
int mul(int,int);
int sub(int,int);
float div(float,int);

int main(void)
{
  int num1,num2,total=0;
  char choice;
  float totalf=0;
  printf("Please enter the numbers\n\n\t\tNumbers: ");
  scanf("%d",&num1);
  printf("\n\nNumber2: ");
  scanf("%d",&num2);
  printf("\n\n\tOperations: Add--A Sub--S  Mul--M  Div--D\n\n\t\tChoice: ");
	getchar();  // this is used based on the previous statement wherien the enter was counted as a character 
	// for the next statement
  scanf("%c",&choice);

printf("Entered number is %c",choice);

  switch(choice)
  {
    case 'a' :
	    {
             total=add(num1,num2);
	     break;
	    } 
    case 's':
            {
             total=sub(num1,num2);
	     break;
	    }
    case 'm':
            {
	     total=mul(num1,num2);
	     break;
	    }
    case 'd':
            {
             totalf=div(num1,num2);
	     printf("Result = %f",totalf);
	     return 0;
	    }
    default:
    printf("\n\t\t\tWrong selection was made");
    return 1;    
  }
   printf("\n\n\t\tResult: %d",total);
  return 0;
}

int add(int a,int b)
{return(a+b);}

int mul(int a,int b)
{return(a*b);}

int sub(int a,int b)
{return(a-b);}

float div(float a,int b)

{return(a/b);}

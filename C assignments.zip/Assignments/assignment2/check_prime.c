
#include<stdio.h>
#include<math.h>

int main(void)

{
       double input;
       int max_root;
       printf("\n\t\tThis program checks whether the given input number is prime or not\n");
       printf("\n\n\tPlease enter the number: ");
       
       scanf("%lf",&input);

       max_root=(int) sqrt(input);
       ++max_root;
       
       while(max_root!=1)
       {
        if((int)input % max_root==0)
	{
	printf("\nNumber is not Prime\n");
	return 0;
	}
	else
		--max_root;
       }
       printf("Number %d is Prime\n\n",(int) input);
       return 0;
}

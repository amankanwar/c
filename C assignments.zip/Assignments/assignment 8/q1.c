/*Q1. Define your own iterative functions for
(using array notation as well as exclusively using pointers)
a) finding length
b) copying
c) concatenation
d) comparision
e) reversing in memory
f) finding first occurrence of given character
g)finding last occurrence of given character
h)counting no.of occurences of a given character
i) finding a substring in a main string
j) Whether a string starts or ends with a particular sub string */

#include<stdio.h>


//======================= Definitions =================================================

int finding_length(char *);

void string_copy(char*, char*);

void string_concat(char*,char*);

int string_comparison(char *, char *);

void reverse(char *);

int first_occurence(char *, char);        // takes input of whole string and character // returns string index if character found, else return negative number

int finding_last_occurence(char *, char);  //

int total_occurence(char *, char);        // returns the total number for count of the given character in the input string by the user

int find_substring(char*, char*);         // takes main string and substring as parameters and returns the result accordingly

//======================================================================================


//======================================================================================
int main(void)
{


}
//======================================================================================

int finding_length(char *input_string)
{
 int length = 0;
 while(input_string[length++] != '\n');
 return length;
}

//	=	=	=	=	=	=	=	=	=	=	=

void string_copy(char *destination , const char *source)
{
 int len=0,i=0;
 
 len = finding_length(source);
 
 while(i<len)
 {
  destination[i] = source[i];                                    
 }
 
}

//	=	=	=	=	=	=	=	=	=	=	=

void string_concat(char *desitnation,const char *source)
{
 int len_destination=0,len_source=0;

 len_destination = finding_length(destination);
 len_source      = finding_length(source);

 int new_index = len_destination;

 int source_strating=0;

        while(source_starting<len_source)
 	{
         destination[len_destination] = source[source_starting];
	 source_starting++;
        }
}

//	=	=	=	=	=	=	=	=	=	=	=

int string_comparison(const char *string1, const char *string2)
{
  int difference=0;
  int len1=0, len2=0, i=0, loop_len=0;
 
  len1 = finding_length(string1);
  len2 = finding_length(string2);

  loop_length = (len1>=len2)? len1 : len2;
  	  
//--------------------------------------------  
    while(i<=loop_length)
    {
      if(string1[i] != string[i])
      {
        difference = string1[i] - string2[i];
	return difference;
      }
    }
//---------------------------------------------    
  return 0;
}

//	=	=	=	=	=	=	=	=	=	=	=

void reverse(char *string_to_reverse)
{
 int index=0;
 int string_length = finding_length(string_to_reverse);
 
 string_length--;             // so that the given length only point to the last character in the string

 while(index <string_length)
 {
  char temp = string_to_reverse[index];
  string_to_revese[index] = string_to_reverse[string_length];
  string_to_reverse[string_length] = temp;
  //---Increment the index and decrement the last element of string 
  index++;
  string_length--;
 } 
  
}

//	=	=	=	=	=	=	=	=	=	=	=

int first_occurance(char *input_string, char char_to_search)        // takes input of whole string and character
{
  int string_length = finding_length(input_string);
  int index=0;

  while(index < string_length)
  {
     if(input_string[index] == char_to_search)	
     {  
       return index;
     }
     index++;
  }
  return -1;   // to make show that there are no results for the given characrter in the entered character, hence the results for the same counld not be acheived  
}
//	=	=	=	=	=	=	=	=	=	=	=



//	=	=	=	=	=	=	=	=	=	=	=
int finding_last_occurence(char *input_string, char char_to_search)        // takes input of whole string and character and returns the last index
{
  int string_length = finding_length(input_string);
  int index=0;

  string_length--;

  while(index <= string_length)
  {
     if(input_string[string_length] == char_to_search)	
     {  
       return index;
     }
     string_length--;
  }
  
  return -1;
}


//	=	=	=	=	=	=	=	=	=	=	=
int total_occurence(char *input_string, char char_to_search)        // takes input of whole string and finds the count for the given char appearance
{
  int string_length = finding_length(input_string);
  int index=0;
  int count=0;

  while(index < string_length)
  {
     if(input_string[index] == char_to_search)	
     {  
       count++;
     }
     index++;
  }
  return count;   // to make show that there are no results for the given characrter in the entered character, hence the results for the same counld not be acheived  
}
//	=	=	=	=	=	=	=	=	=	=	


char find_substring(char *input_string, char *sub_string)         // takes main string and substring as parameters and returns the result accordingly
{

 int len_string      =  finding_length(input_string);
 int len_sub_string  =  finding_length(sub_string); 
 int j =0, count=0;
 char result;

   while(j < len_string)                                        // this loop will count the occurance of a given substring's first character
   { 
      count    = total_occurence(char *input_string, sub_string[0]); 
   }

  //checking whether the substring is present in the main string
  
   if(count > 0)
   {

 	 // here we have the count, for the total times the given first character to array  is repeated)
    
  	 int index[count+0];        // creating an array of size based on the number of character counts in the given array
	
	  // based on this occurance we will intiate a loop to look for the given substring in the main string
 
	  j = 0; 

	 // Loop to implement on the basis of the count we have
      while(j< count)
 	 {	 
 	   index[j] = first_occurence(input_string,sub_string[0]);
	  // here we will call the function first_occurence() by the idea presented below, 
	  // The loop will start with the initial value of j=0; given that we will gather the indexes of all the first element present in string 
	   // index[j] = first_occurence(input_string+index[j-1],sub_string[j])
         }
   char result = find_substring_II(const char *input_string, const char *sub_string, int *index, int len) // this function is a specially implemented
   }
   else
   {
     // substring is not present in the given input string
   }

}

// this function needs to be declared, yet not declared

int find_substring_II(const char *input_string, const char *sub_string, int *index, int len) // this function is a specially implemented
{
 int index=;

}
